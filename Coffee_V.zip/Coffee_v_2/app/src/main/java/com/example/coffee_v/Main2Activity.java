package com.example.coffee_v;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    Button btnNewAct;
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btnNewAct = findViewById(R.id.buttonStarter);
        imageView = findViewById(R.id.coffeeIcon);

    }


    public void startCoffee(View view) {


            Intent intent = new Intent(this, MainActivity.class);
            Pair[] pairs = new Pair[2];

            pairs[0] = new Pair<View, String>(btnNewAct, "buttonTransition");
        pairs[1] = new Pair<View, String>(imageView, "imageTransition");
            ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(this, pairs);

            startActivity(intent, options.toBundle());


    }
}
