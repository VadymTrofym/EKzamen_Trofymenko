package com.example.coffee_v;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import com.scwang.wave.MultiWaveHeader;

import java.text.NumberFormat;
import java.util.concurrent.Delayed;


public class MainActivity extends AppCompatActivity {
    MultiWaveHeader waveHeader,waveFooter;
    Button bPLus,bMinus,zakaz,newActivity;
    TextView textViewPrice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        waveHeader = findViewById(R.id.wave_header);
        waveFooter = findViewById(R.id.wave_footer);


        waveHeader.setVelocity(5);
        waveFooter.setVelocity(3);
        waveHeader.setProgress(1);
        waveHeader.isRunning();
        waveHeader.setGradientAngle(45);
        waveHeader.setWaveHeight(40);
        waveHeader.setStartColor(Color.RED);
        waveHeader.setCloseColor(Color.MAGENTA);
        bPLus = findViewById(R.id.plus);
        bMinus = findViewById(R.id.minus);
        zakaz = findViewById(R.id.button);
        textViewPrice = findViewById(R.id.price_text_view);





    }

    public int numberOfCoffee =0;




    public void submitOrder(View view) {
        Animation animationZakazat = AnimationUtils.loadAnimation(this,R.anim.mixed_anim);
        zakaz.startAnimation(animationZakazat);

        Animation animationZakazatShowPrice = AnimationUtils.loadAnimation(this,R.anim.blink_anim);
        textViewPrice.startAnimation(animationZakazatShowPrice);


        display(numberOfCoffee);
        displayPrice(numberOfCoffee * 10);
    }


    private void display(int number){
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText(""+number);
    }

    public void displayPrice(int number) {
        TextView priceTextView = findViewById(R.id.price_text_view);

        priceTextView.setText(NumberFormat.getCurrencyInstance().format (number));

    }










    public void increment(View view) {
        numberOfCoffee++;
        display(numberOfCoffee);
        Animation animationPlus = AnimationUtils.loadAnimation(this,R.anim.zoomin);
        bPLus.startAnimation(animationPlus);

    }
    public void decrement(View view) {
        Animation animationMinus = AnimationUtils.loadAnimation(this,R.anim.zoomout);
        bMinus.startAnimation(animationMinus);


        numberOfCoffee--;
        if (numberOfCoffee <=0){
            numberOfCoffee = 1;
        }
        display(numberOfCoffee);

    }



}
